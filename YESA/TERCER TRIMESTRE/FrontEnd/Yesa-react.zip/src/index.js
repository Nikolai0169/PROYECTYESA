import React from 'react'
import ReactDOM from 'react-dom'
import {
  BrowserRouter as Router,
  Route,
  Switch,
  Redirect,
} from 'react-router-dom'

import './style.css'
import Alcancas from './views/alcancas'
import Rectangle from './views/rectangle'
import Frame45000 from './views/frame45000'
import Rectangle1 from './views/rectangle1'
import Hermosaalcancaartesanalparaahorrarconestilo from './views/hermosaalcancaartesanalparaahorrarconestilo'
import Floreros from './views/floreros'
import IMAGE from './views/image'
import Florerodecorativonicoparaembellecertuhogar from './views/florerodecorativonicoparaembellecertuhogar'
import Rectangle2 from './views/rectangle2'
import Rectangle3 from './views/rectangle3'
import Frame25000 from './views/frame25000'
import AlcancaCermicaRosa from './views/alcanca-cermica-rosa'
import Frame35000 from './views/frame35000'
import Rectangle4 from './views/rectangle4'
import Checkboxes from './views/checkboxes'
import Rectangle5 from './views/rectangle5'
import Rectangle6 from './views/rectangle6'
import Rectangle7 from './views/rectangle7'
import Rectangle8 from './views/rectangle8'
import FrameHolaSoytuchatdesoporteEnqutepuedoayudar from './views/frame-hola-soytuchatdesoporte-enqutepuedoayudar'
import Florerodecorativonicoparaembellecertuhogar1 from './views/florerodecorativonicoparaembellecertuhogar1'
import Rectangle9 from './views/rectangle9'
import Genericavatar from './views/genericavatar'
import Favoritos from './views/favoritos'
import Rectangle10 from './views/rectangle10'
import Eliminar from './views/eliminar'
import Frame250001 from './views/frame250001'
import Checkboxes1 from './views/checkboxes1'
import Rectangle11 from './views/rectangle11'
import IMAGE1 from './views/image1'
import IMAGE2 from './views/image2'
import Frame8 from './views/frame8'
import Frame28000 from './views/frame28000'
import Frame60000 from './views/frame60000'
import Rectangle12 from './views/rectangle12'
import Frame450001 from './views/frame450001'
import Ver from './views/ver'
import Comprar from './views/comprar'
import Frame450002 from './views/frame450002'
import Rectangle13 from './views/rectangle13'
import Frame from './views/frame'
import Rectangle14 from './views/rectangle14'
import Rectangle15 from './views/rectangle15'
import Rectangle16 from './views/rectangle16'
import Rectangle17 from './views/rectangle17'
import Frame9 from './views/frame9'
import Frame19000 from './views/frame19000'
import Rectangle18 from './views/rectangle18'
import Pocillonicohechoamanoparadisfrutartucaf from './views/pocillonicohechoamanoparadisfrutartucaf'
import Checkboxes2 from './views/checkboxes2'
import Rectangle19 from './views/rectangle19'
import PocilloArtesanalVioleta from './views/pocillo-artesanal-violeta'
import Florerodecorativonicoparaembellecertuhogar2 from './views/florerodecorativonicoparaembellecertuhogar2'
import Chateaconnuestrochatdesoporte from './views/chateaconnuestrochatdesoporte'
import Ver1 from './views/ver1'
import Pocillonicohechoamanoparadisfrutartucaf1 from './views/pocillonicohechoamanoparadisfrutartucaf1'
import Frame2 from './views/frame2'
import Pocillos from './views/pocillos'
import Genericavatar1 from './views/genericavatar1'
import Ver2 from './views/ver2'
import Rectangle20 from './views/rectangle20'
import Frame600001 from './views/frame600001'
import Rectangle21 from './views/rectangle21'
import Rectangle22 from './views/rectangle22'
import Rectangle23 from './views/rectangle23'
import Rectangle24 from './views/rectangle24'
import Rectangle25 from './views/rectangle25'
import Historialdecompras from './views/historialdecompras'
import Stepper from './views/stepper'
import Rectangle26 from './views/rectangle26'
import Rectangle27 from './views/rectangle27'
import IMAGE3 from './views/image3'
import Rectangle28 from './views/rectangle28'
import Frame600002 from './views/frame600002'
import Checkboxes3 from './views/checkboxes3'
import Rectangle29 from './views/rectangle29'
import Rectangle30 from './views/rectangle30'
import Frame5 from './views/frame5'
import Frame3 from './views/frame3'
import Frame190001 from './views/frame190001'
import Frame6 from './views/frame6'
import Hermosaalcancaartesanalparaahorrarconestilo1 from './views/hermosaalcancaartesanalparaahorrarconestilo1'
import FloreroElegante from './views/florero-elegante'
import Frame280001 from './views/frame280001'
import Rectangle31 from './views/rectangle31'
import Rectangle32 from './views/rectangle32'
import Frame1 from './views/frame1'
import IMAGE4 from './views/image4'
import Frame7 from './views/frame7'
import Rectangle33 from './views/rectangle33'
import Rectangle34 from './views/rectangle34'
import AlcancaCermicaRosa1 from './views/alcanca-cermica-rosa1'
import IMAGE5 from './views/image5'
import Alcancas1 from './views/alcancas1'
import IMAGE6 from './views/image6'
import Rectangle35 from './views/rectangle35'
import FloreroElegante1 from './views/florero-elegante1'
import Rectangle36 from './views/rectangle36'
import Frame350001 from './views/frame350001'
import PocilloArtesanalVioleta1 from './views/pocillo-artesanal-violeta1'
import FloreroElegante2 from './views/florero-elegante2'
import Chatdesoporte from './views/chatdesoporte'
import NotFound from './views/not-found'

const App = () => {
  return (
    <Router>
      <Switch>
        <Route component={Alcancas} exact path="/alcancas" />
        <Route component={Rectangle} exact path="/rectangle" />
        <Route component={Frame45000} exact path="/frame45000" />
        <Route component={Rectangle1} exact path="/rectangle1" />
        <Route
          component={Hermosaalcancaartesanalparaahorrarconestilo}
          exact
          path="/hermosaalcancaartesanalparaahorrarconestilo"
        />
        <Route component={Floreros} exact path="/floreros" />
        <Route component={IMAGE} exact path="/image" />
        <Route
          component={Florerodecorativonicoparaembellecertuhogar}
          exact
          path="/florerodecorativonicoparaembellecertuhogar"
        />
        <Route component={Rectangle2} exact path="/rectangle2" />
        <Route component={Rectangle3} exact path="/rectangle3" />
        <Route component={Frame25000} exact path="/frame25000" />
        <Route
          component={AlcancaCermicaRosa}
          exact
          path="/alcanca-cermica-rosa"
        />
        <Route component={Frame35000} exact path="/frame35000" />
        <Route component={Rectangle4} exact path="/rectangle4" />
        <Route component={Checkboxes} exact path="/checkboxes" />
        <Route component={Rectangle5} exact path="/rectangle5" />
        <Route component={Rectangle6} exact path="/rectangle6" />
        <Route component={Rectangle7} exact path="/rectangle7" />
        <Route component={Rectangle8} exact path="/rectangle8" />
        <Route
          component={FrameHolaSoytuchatdesoporteEnqutepuedoayudar}
          exact
          path="/frame-hola-soytuchatdesoporte-enqutepuedoayudar"
        />
        <Route
          component={Florerodecorativonicoparaembellecertuhogar1}
          exact
          path="/florerodecorativonicoparaembellecertuhogar1"
        />
        <Route component={Rectangle9} exact path="/rectangle9" />
        <Route component={Genericavatar} exact path="/genericavatar" />
        <Route component={Favoritos} exact path="/favoritos" />
        <Route component={Rectangle10} exact path="/rectangle10" />
        <Route component={Eliminar} exact path="/eliminar" />
        <Route component={Frame250001} exact path="/frame250001" />
        <Route component={Checkboxes1} exact path="/checkboxes1" />
        <Route component={Rectangle11} exact path="/rectangle11" />
        <Route component={IMAGE1} exact path="/image1" />
        <Route component={IMAGE2} exact path="/image2" />
        <Route component={Frame8} exact path="/frame8" />
        <Route component={Frame28000} exact path="/frame28000" />
        <Route component={Frame60000} exact path="/frame60000" />
        <Route component={Rectangle12} exact path="/rectangle12" />
        <Route component={Frame450001} exact path="/frame450001" />
        <Route component={Ver} exact path="/ver" />
        <Route component={Comprar} exact path="/comprar" />
        <Route component={Frame450002} exact path="/frame450002" />
        <Route component={Rectangle13} exact path="/rectangle13" />
        <Route component={Frame} exact path="/frame" />
        <Route component={Rectangle14} exact path="/rectangle14" />
        <Route component={Rectangle15} exact path="/rectangle15" />
        <Route component={Rectangle16} exact path="/rectangle16" />
        <Route component={Rectangle17} exact path="/rectangle17" />
        <Route component={Frame9} exact path="/frame9" />
        <Route component={Frame19000} exact path="/frame19000" />
        <Route component={Rectangle18} exact path="/rectangle18" />
        <Route
          component={Pocillonicohechoamanoparadisfrutartucaf}
          exact
          path="/pocillonicohechoamanoparadisfrutartucaf"
        />
        <Route component={Checkboxes2} exact path="/checkboxes2" />
        <Route component={Rectangle19} exact path="/rectangle19" />
        <Route
          component={PocilloArtesanalVioleta}
          exact
          path="/pocillo-artesanal-violeta"
        />
        <Route
          component={Florerodecorativonicoparaembellecertuhogar2}
          exact
          path="/florerodecorativonicoparaembellecertuhogar2"
        />
        <Route
          component={Chateaconnuestrochatdesoporte}
          exact
          path="/chateaconnuestrochatdesoporte"
        />
        <Route component={Ver1} exact path="/ver1" />
        <Route
          component={Pocillonicohechoamanoparadisfrutartucaf1}
          exact
          path="/pocillonicohechoamanoparadisfrutartucaf1"
        />
        <Route component={Frame2} exact path="/" />
        <Route component={Pocillos} exact path="/pocillos" />
        <Route component={Genericavatar1} exact path="/genericavatar1" />
        <Route component={Ver2} exact path="/ver2" />
        <Route component={Rectangle20} exact path="/rectangle20" />
        <Route component={Frame600001} exact path="/frame600001" />
        <Route component={Rectangle21} exact path="/rectangle21" />
        <Route component={Rectangle22} exact path="/rectangle22" />
        <Route component={Rectangle23} exact path="/rectangle23" />
        <Route component={Rectangle24} exact path="/rectangle24" />
        <Route component={Rectangle25} exact path="/rectangle25" />
        <Route
          component={Historialdecompras}
          exact
          path="/historialdecompras"
        />
        <Route component={Stepper} exact path="/stepper" />
        <Route component={Rectangle26} exact path="/rectangle26" />
        <Route component={Rectangle27} exact path="/rectangle27" />
        <Route component={IMAGE3} exact path="/image3" />
        <Route component={Rectangle28} exact path="/rectangle28" />
        <Route component={Frame600002} exact path="/frame600002" />
        <Route component={Checkboxes3} exact path="/checkboxes3" />
        <Route component={Rectangle29} exact path="/rectangle29" />
        <Route component={Rectangle30} exact path="/rectangle30" />
        <Route component={Frame5} exact path="/frame5" />
        <Route component={Frame3} exact path="/frame3" />
        <Route component={Frame190001} exact path="/frame190001" />
        <Route component={Frame6} exact path="/frame6" />
        <Route
          component={Hermosaalcancaartesanalparaahorrarconestilo1}
          exact
          path="/hermosaalcancaartesanalparaahorrarconestilo1"
        />
        <Route component={FloreroElegante} exact path="/florero-elegante" />
        <Route component={Frame280001} exact path="/frame280001" />
        <Route component={Rectangle31} exact path="/rectangle31" />
        <Route component={Rectangle32} exact path="/rectangle32" />
        <Route component={Frame1} exact path="/frame1" />
        <Route component={IMAGE4} exact path="/image4" />
        <Route component={Frame7} exact path="/frame7" />
        <Route component={Rectangle33} exact path="/rectangle33" />
        <Route component={Rectangle34} exact path="/rectangle34" />
        <Route
          component={AlcancaCermicaRosa1}
          exact
          path="/alcanca-cermica-rosa1"
        />
        <Route component={IMAGE5} exact path="/image5" />
        <Route component={Alcancas1} exact path="/alcancas1" />
        <Route component={IMAGE6} exact path="/image6" />
        <Route component={Rectangle35} exact path="/rectangle35" />
        <Route component={FloreroElegante1} exact path="/florero-elegante1" />
        <Route component={Rectangle36} exact path="/rectangle36" />
        <Route component={Frame350001} exact path="/frame350001" />
        <Route
          component={PocilloArtesanalVioleta1}
          exact
          path="/pocillo-artesanal-violeta1"
        />
        <Route component={FloreroElegante2} exact path="/florero-elegante2" />
        <Route component={Chatdesoporte} exact path="/chatdesoporte" />
        <Route component={NotFound} path="**" />
        <Redirect to="**" />
      </Switch>
    </Router>
  )
}

ReactDOM.render(<App />, document.getElementById('app'))
