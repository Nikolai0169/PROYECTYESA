import React from 'react'

import { Helmet } from 'react-helmet'

import './frame7.css'

const Frame7 = (props) => {
  return (
    <div className="frame7-container1">
      <Helmet>
        <title>Frame7 - exported project</title>
        <meta property="og:title" content="Frame7 - exported project" />
        <link
          rel="canonical"
          href="https://yesa-okpqiu.teleporthq.app/frame7"
        />
      </Helmet>
      <div className="frame7-frame7">
        <img
          alt="Rectangle7381"
          src="/rectangle7381-lvtk-1700w.png"
          className="frame7-rectangle10"
        />
        <img
          alt="Rectangle7382"
          src="/rectangle7382-92he-200h.png"
          className="frame7-rectangle11"
        />
        <span className="frame7-text10">Personaliza tu Producto</span>
        <span className="frame7-text11">
          Crea una pieza única con tu imagen y color favorito
        </span>
        <img
          alt="Rectangle7310"
          src="/rectangle7310-845-1000h.png"
          className="frame7-rectangle12"
        />
        <span className="frame7-text12">👁️</span>
        <span className="frame7-text13">Vista Previa</span>
        <img
          alt="Rectangle7311"
          src="/rectangle7311-8aps-900h.png"
          className="frame7-rectangle13"
        />
        <img
          alt="Rectangle7311"
          src="/rectangle7311-ji5v-500h.png"
          className="frame7-rectangle14"
        />
        <span className="frame7-text14">🏺</span>
        <span className="frame7-text15">Tu producto personalizado</span>
        <img
          alt="Rectangle7311"
          src="/rectangle7311-5rc8-200h.png"
          className="frame7-rectangle15"
        />
        <span className="frame7-text16">Especificaciones:</span>
        <span className="frame7-text17">
          Introduce aquí tus especificaciones adicionales
        </span>
        <img
          alt="Rectangle7312"
          src="/rectangle7312-lraq-200h.png"
          className="frame7-rectangle16"
        />
        <img
          alt="Rectangle7312"
          src="/rectangle7312-mqm-200h.png"
          className="frame7-rectangle17"
        />
        <span className="frame7-text18">🛒 Agregar al Carrito</span>
        <img
          alt="Rectangle793"
          src="/rectangle793-hygr-200h.png"
          className="frame7-rectangle18"
        />
        <span className="frame7-text19">Cotizar producto</span>
        <img
          alt="Rectangle7312"
          src="/rectangle7312-0wn6-200h.png"
          className="frame7-rectangle19"
        />
        <span className="frame7-text20">💾 Guardar Diseño</span>
        <img
          alt="Rectangle7312"
          src="/rectangle7312-duot-200h.png"
          className="frame7-rectangle20"
        />
        <span className="frame7-text21">📤 Compartir</span>
        <span className="frame7-text22">¿Necesitas ayuda con tu diseño?</span>
        <span className="frame7-text23">💬 Contactar Asesor</span>
        <img
          alt="Rectangle7385"
          src="/rectangle7385-3klw-400h.png"
          className="frame7-rectangle21"
        />
        <span className="frame7-text24">🖼️</span>
        <span className="frame7-text25">Imagen Personalizada</span>
        <img
          alt="Rectangle7388"
          src="/rectangle7388-i1fm-200h.png"
          className="frame7-rectangle22"
        />
        <span className="frame7-text26">📁</span>
        <span className="frame7-text27">
          Arrastra tu imagen aquí o haz clic para seleccionar
        </span>
        <img
          alt="Rectangle7391"
          src="/rectangle7391-zmx4-200h.png"
          className="frame7-rectangle23"
        />
        <span className="frame7-text28">Seleccionar Imagen</span>
        <span className="frame7-text29">
          • Formatos soportados: JPG, PNG, GIF
        </span>
        <span className="frame7-text30">• Tamaño máximo: 5MB</span>
        <span className="frame7-text31">
          • Resolución recomendada: 1000x1000px
        </span>
      </div>
      <a href="https://play.teleporthq.io/signup" className="frame7-link">
        <div aria-label="Sign up to TeleportHQ" className="frame7-container2">
          <svg
            width="24"
            height="24"
            viewBox="0 0 19 21"
            fill="none"
            xmlns="http://www.w3.org/2000/svg"
            className="frame7-icon1"
          >
            <path
              d="M9.1017 4.64355H2.17867C0.711684 4.64355 -0.477539 5.79975 -0.477539 7.22599V13.9567C-0.477539 15.3829 0.711684 16.5391 2.17867 16.5391H9.1017C10.5687 16.5391 11.7579 15.3829 11.7579 13.9567V7.22599C11.7579 5.79975 10.5687 4.64355 9.1017 4.64355Z"
              fill="#B23ADE"
            ></path>
            <path
              d="M10.9733 12.7878C14.4208 12.7878 17.2156 10.0706 17.2156 6.71886C17.2156 3.3671 14.4208 0.649963 10.9733 0.649963C7.52573 0.649963 4.73096 3.3671 4.73096 6.71886C4.73096 10.0706 7.52573 12.7878 10.9733 12.7878Z"
              fill="#FF5C5C"
            ></path>
            <path
              d="M17.7373 13.3654C19.1497 14.1588 19.1497 15.4634 17.7373 16.2493L10.0865 20.5387C8.67402 21.332 7.51855 20.6836 7.51855 19.0968V10.5141C7.51855 8.92916 8.67402 8.2807 10.0865 9.07221L17.7373 13.3654Z"
              fill="#2874DE"
            ></path>
          </svg>
          <span className="frame7-text32">Built in TeleportHQ</span>
        </div>
      </a>
    </div>
  )
}

export default Frame7
