import React from 'react'

import { Helmet } from 'react-helmet'

import './frame1.css'

const Frame1 = (props) => {
  return (
    <div className="frame1-container1">
      <Helmet>
        <title>Frame1 - exported project</title>
        <meta property="og:title" content="Frame1 - exported project" />
        <link
          rel="canonical"
          href="https://yesa-okpqiu.teleporthq.app/frame1"
        />
      </Helmet>
      <div className="frame1-frame1">
        <img
          alt="Rectangle6118"
          src="/rectangle6118-zqwi-1300w.png"
          className="frame1-rectangle10"
        />
        <img
          alt="Rectangle6118"
          src="/rectangle6118-8116-300h.png"
          className="frame1-rectangle11"
        />
        <span className="frame1-text100">¡OFERTAS ESPECIALES!</span>
        <span className="frame1-text101">
          Descuentos hasta del 30% en productos seleccionados
        </span>
        <img
          alt="Rectangle6118"
          src="/rectangle6118-9p3-200h.png"
          className="frame1-rectangle12"
        />
        <span className="frame1-text102">Ver Ofertas</span>
        <span className="frame1-text103">Ofertas Especiales</span>
        <span className="frame1-text104">
          Aprovecha estos descuentos únicos por tiempo limitado
        </span>
        <img
          alt="Rectangle6119"
          src="/rectangle6119-vo2-400h.png"
          className="frame1-rectangle13"
        />
        <img
          alt="IMAGE6119"
          src="/image6119-6db6-200h.png"
          className="frame1image10"
        />
        <span className="frame1-text105">Alcancía Cerámica Rosa</span>
        <span className="frame1-text106">$19.600</span>
        <span className="frame1-text107">$28.000</span>
        <span className="frame1-text108">Ahorras: $</span>
        <span className="frame1-text109">8400</span>
        <img
          alt="Rectangle6119"
          src="/rectangle6119-8it9-200h.png"
          className="frame1-rectangle14"
        />
        <span className="frame1-text110">🛒 Agregar al Carrito</span>
        <img
          alt="Rectangle6119"
          src="/rectangle6119-gr7f-400h.png"
          className="frame1-rectangle15"
        />
        <img
          alt="IMAGE6120"
          src="/image6120-6qc-200h.png"
          className="frame1image11"
        />
        <span className="frame1-text111">Pocillo Artesanal Violeta</span>
        <span className="frame1-text112">$13.300</span>
        <span className="frame1-text113">$19.000</span>
        <span className="frame1-text114">Ahorras: $</span>
        <span className="frame1-text115">5700</span>
        <img
          alt="Rectangle6120"
          src="/rectangle6120-xpqr-200h.png"
          className="frame1-rectangle16"
        />
        <span className="frame1-text116">🛒 Agregar al Carrito</span>
        <img
          alt="Rectangle6120"
          src="/rectangle6120-qw7-400h.png"
          className="frame1-rectangle17"
        />
        <img
          alt="IMAGE6120"
          src="/image6120-qe0g-200h.png"
          className="frame1image12"
        />
        <span className="frame1-text117">Florero Elegante</span>
        <span className="frame1-text118">$31.500</span>
        <span className="frame1-text119">$45.000</span>
        <span className="frame1-text120">Ahorras: $</span>
        <span className="frame1-text121">13.500</span>
        <img
          alt="Rectangle6121"
          src="/rectangle6121-nq09-200h.png"
          className="frame1-rectangle18"
        />
        <span className="frame1-text122">🛒 Agregar al Carrito</span>
        <img
          alt="Rectangle6121"
          src="/rectangle6121-p1kn-400h.png"
          className="frame1-rectangle19"
        />
        <img
          alt="IMAGE6121"
          src="/image6121-t3dp-200h.png"
          className="frame1image13"
        />
        <span className="frame1-text123">Set de Pocillos</span>
        <span className="frame1-text124">$33.600</span>
        <span className="frame1-text125">$48.000</span>
        <span className="frame1-text126">Ahorras: $</span>
        <span className="frame1-text127">14.400</span>
        <img
          alt="Rectangle6122"
          src="/rectangle6122-8l4w-200h.png"
          className="frame1-rectangle20"
        />
        <span className="frame1-text128">🛒 Agregar al Carrito</span>
        <img
          alt="Rectangle6122"
          src="/rectangle6122-ap8v-400h.png"
          className="frame1-rectangle21"
        />
        <img
          alt="IMAGE6122"
          src="/image6122-1mwj-200h.png"
          className="frame1image14"
        />
        <span className="frame1-text129">Vasija Decorativa</span>
        <span className="frame1-text130">$45.500</span>
        <span className="frame1-text131">$65.000</span>
        <span className="frame1-text132">Ahorras: $</span>
        <span className="frame1-text133">19.500</span>
        <img
          alt="Rectangle6123"
          src="/rectangle6123-287q-200h.png"
          className="frame1-rectangle22"
        />
        <span className="frame1-text134">🛒 Agregar al Carrito</span>
        <img
          alt="Rectangle6123"
          src="/rectangle6123-5za-400h.png"
          className="frame1-rectangle23"
        />
        <img
          alt="IMAGE6123"
          src="/image6123-fhkq-200h.png"
          className="frame1image15"
        />
        <span className="frame1-text135">Plato Llano Premium</span>
        <span className="frame1-text136">$22.400</span>
        <span className="frame1-text137">$32.000</span>
        <span className="frame1-text138">Ahorras: $</span>
        <span className="frame1-text139">9600</span>
        <img
          alt="Rectangle6124"
          src="/rectangle6124-bbmh-200h.png"
          className="frame1-rectangle24"
        />
        <span className="frame1-text140">🛒 Agregar al Carrito</span>
        <img
          alt="Rectangle6124"
          src="/rectangle6124-d4d-200h.png"
          className="frame1-rectangle25"
        />
        <span className="frame1-text141">Ver Todas las Ofertas</span>
        <img
          alt="Rectangle6124"
          src="/rectangle6124-vpp8-300h.png"
          className="frame1-rectangle26"
        />
        <span className="frame1-text142">¡Tiempo Limitado!</span>
        <span className="frame1-text143">
          Estas ofertas especiales terminan pronto. No te las pierdas.
        </span>
        <span className="frame1-text144">02</span>
        <span className="frame1-text145">Días</span>
        <span className="frame1-text146">14</span>
        <span className="frame1-text147">Horas</span>
        <span className="frame1-text148">35</span>
        <span className="frame1-text149">Minutos</span>
        <span className="frame1-text150">Categorías en Oferta</span>
        <img
          alt="Rectangle6125"
          src="/rectangle6125-373s-200h.png"
          className="frame1-rectangle27"
        />
        <span className="frame1-text151">🏺</span>
        <span className="frame1-text152">Alcancías</span>
        <span className="frame1-text153">Hasta 30% de descuento</span>
        <img
          alt="Rectangle6126"
          src="/rectangle6126-uihv-200h.png"
          className="frame1-rectangle28"
        />
        <span className="frame1-text154">Pocillos</span>
        <span className="frame1-text155">Hasta 25% de descuento</span>
        <img
          alt="Rectangle6126"
          src="/rectangle6126-qs4-200h.png"
          className="frame1-rectangle29"
        />
        <span className="frame1-text156">🌸</span>
        <span className="frame1-text157">Floreros</span>
        <span className="frame1-text158">Hasta 20% de descuento</span>
        <img
          alt="Rectangle6127"
          src="/rectangle6127-wacg-3300h.png"
          className="frame1-rectangle30"
        />
        <span className="frame1-text159">Todos Nuestros Productos</span>
        <span className="frame1-text160">
          Explora nuestra colección completa de cerámica artesanal
        </span>
        <span className="frame1-text161">🏺</span>
        <span className="frame1-text162">Alcancías</span>
        <span className="frame1-text163">
          Hermosas alcancías artesanales para ahorrar con estilo
        </span>
        <img
          alt="Rectangle6127"
          src="/rectangle6127-022-400h.png"
          className="frame1-rectangle31"
        />
        <img
          alt="IMAGE6127"
          src="/image6127-siy-200h.png"
          className="frame1image16"
        />
        <span className="frame1-text164">Alcancía Cerámica Rosa</span>
        <img
          alt="Rectangle6128"
          src="/rectangle6128-ced-200h.png"
          className="frame1-rectangle32"
        />
        <span className="frame1-text165">Agregar al Carrito</span>
        <img
          alt="Rectangle6128"
          src="/rectangle6128-k6owp-400h.png"
          className="frame1-rectangle33"
        />
        <img
          alt="IMAGE6128"
          src="/image6128-tq7d-300w.png"
          className="frame1image17"
        />
        <span className="frame1-text166">Alcancía Infantil</span>
        <img
          alt="Rectangle6128"
          src="/rectangle6128-pxso-200h.png"
          className="frame1-rectangle34"
        />
        <span className="frame1-text167">Agregar al Carrito</span>
        <img
          alt="Rectangle6128"
          src="/rectangle6128-aroh-400h.png"
          className="frame1-rectangle35"
        />
        <img
          alt="IMAGE6129"
          src="/image6129-8w03-300w.png"
          className="frame1image18"
        />
        <span className="frame1-text168">Alcancía Vintage</span>
        <img
          alt="Rectangle6129"
          src="/rectangle6129-6zhu-200h.png"
          className="frame1-rectangle36"
        />
        <span className="frame1-text169">Agregar al Carrito</span>
        <img
          alt="Rectangle6129"
          src="/rectangle6129-k81d-400h.png"
          className="frame1-rectangle37"
        />
        <img
          alt="IMAGE6129"
          src="/image6129-rvl2-200h.png"
          className="frame1image19"
        />
        <span className="frame1-text170">Alcancía Grande</span>
        <img
          alt="Rectangle6129"
          src="/rectangle6129-hi5c-200h.png"
          className="frame1-rectangle38"
        />
        <span className="frame1-text171">Agregar al Carrito</span>
        <span className="frame1-text172">Pocillos</span>
        <span className="frame1-text173">
          Pocillos únicos hechos a mano para disfrutar tu café
        </span>
        <img
          alt="Rectangle6130"
          src="/rectangle6130-ov8-400h.png"
          className="frame1-rectangle39"
        />
        <img
          alt="IMAGE6130"
          src="/image6130-1pbb-200h.png"
          className="frame1image20"
        />
        <span className="frame1-text174">Pocillo Artesanal Violeta</span>
        <img
          alt="Rectangle6130"
          src="/rectangle6130-d99e-200h.png"
          className="frame1-rectangle40"
        />
        <span className="frame1-text175">Agregar al Carrito</span>
        <img
          alt="Rectangle6131"
          src="/rectangle6131-gvla-400h.png"
          className="frame1-rectangle41"
        />
        <img
          alt="IMAGE6131"
          src="/image6131-9kr-300w.png"
          className="frame1image21"
        />
        <span className="frame1-text176">Taza Decorativa</span>
        <img
          alt="Rectangle6131"
          src="/rectangle6131-uor-200h.png"
          className="frame1-rectangle42"
        />
        <span className="frame1-text177">Agregar al Carrito</span>
        <img
          alt="Rectangle6131"
          src="/rectangle6131-4dp9-400h.png"
          className="frame1-rectangle43"
        />
        <img
          alt="IMAGE6131"
          src="/image6131-6t6-300w.png"
          className="frame1image22"
        />
        <span className="frame1-text178">Set de Pocillos</span>
        <img
          alt="Rectangle6132"
          src="/rectangle6132-tlgb-200h.png"
          className="frame1-rectangle44"
        />
        <span className="frame1-text179">Agregar al Carrito</span>
        <img
          alt="Rectangle6132"
          src="/rectangle6132-vn1e-400h.png"
          className="frame1-rectangle45"
        />
        <img
          alt="IMAGE6132"
          src="/image6132-es6-200h.png"
          className="frame1image23"
        />
        <span className="frame1-text180">Pocillo Café Especial</span>
        <img
          alt="Rectangle6132"
          src="/rectangle6132-88s-200h.png"
          className="frame1-rectangle46"
        />
        <span className="frame1-text181">Agregar al Carrito</span>
        <span className="frame1-text182">🍽️</span>
        <span className="frame1-text183">Platos</span>
        <span className="frame1-text184">
          Platos llanos y hondos elegantes para tu mesa
        </span>
        <img
          alt="Rectangle6133"
          src="/rectangle6133-9bgg-400h.png"
          className="frame1-rectangle47"
        />
        <img
          alt="IMAGE6133"
          src="/image6133-8dd-200h.png"
          className="frame1image24"
        />
        <span className="frame1-text185">Plato Llano Premium</span>
        <img
          alt="Rectangle6133"
          src="/rectangle6133-yf9i-200h.png"
          className="frame1-rectangle48"
        />
        <span className="frame1-text186">Agregar al Carrito</span>
        <img
          alt="Rectangle6133"
          src="/rectangle6133-bvvl-400h.png"
          className="frame1-rectangle49"
        />
        <img
          alt="IMAGE6133"
          src="/image6133-8jee-300w.png"
          className="frame1image25"
        />
        <span className="frame1-text187">Plato Hondo Artesanal</span>
        <img
          alt="Rectangle6134"
          src="/rectangle6134-7oej-200h.png"
          className="frame1-rectangle50"
        />
        <span className="frame1-text188">Agregar al Carrito</span>
        <img
          alt="Rectangle6134"
          src="/rectangle6134-s15s-400h.png"
          className="frame1-rectangle51"
        />
        <img
          alt="IMAGE6134"
          src="/image6134-0xz9-300w.png"
          className="frame1image26"
        />
        <span className="frame1-text189">Plato Llano Clásico</span>
        <img
          alt="Rectangle6134"
          src="/rectangle6134-onur-200h.png"
          className="frame1-rectangle52"
        />
        <span className="frame1-text190">Agregar al Carrito</span>
        <img
          alt="Rectangle6134"
          src="/rectangle6134-rvgo-400h.png"
          className="frame1-rectangle53"
        />
        <img
          alt="IMAGE6135"
          src="/image6135-xvj-200h.png"
          className="frame1image27"
        />
        <span className="frame1-text191">Plato Hondo Familiar</span>
        <img
          alt="Rectangle6135"
          src="/rectangle6135-jn9l-200h.png"
          className="frame1-rectangle54"
        />
        <span className="frame1-text192">Agregar al Carrito</span>
        <img
          alt="Rectangle6135"
          src="/rectangle6135-bc8e-400h.png"
          className="frame1-rectangle55"
        />
        <img
          alt="IMAGE6135"
          src="/image6135-mhjf-200h.png"
          className="frame1image28"
        />
        <span className="frame1-text193">Set Platos Llanos</span>
        <img
          alt="Rectangle6135"
          src="/rectangle6135-p4d5-200h.png"
          className="frame1-rectangle56"
        />
        <span className="frame1-text194">Agregar al Carrito</span>
        <img
          alt="Rectangle6136"
          src="/rectangle6136-n0yp-400h.png"
          className="frame1-rectangle57"
        />
        <img
          alt="IMAGE6136"
          src="/image6136-463kg-300w.png"
          className="frame1image29"
        />
        <span className="frame1-text195">Set Platos Hondos</span>
        <img
          alt="Rectangle6136"
          src="/rectangle6136-4y8q-200h.png"
          className="frame1-rectangle58"
        />
        <span className="frame1-text196">Agregar al Carrito</span>
        <span className="frame1-text197">🌸</span>
        <span className="frame1-text198">Floreros</span>
        <span className="frame1-text199">
          Floreros decorativos únicos para embellecer tu hogar
        </span>
        <img
          alt="Rectangle6137"
          src="/rectangle6137-m5kh-400h.png"
          className="frame1-rectangle59"
        />
        <img
          alt="IMAGE6137"
          src="/image6137-928p-200h.png"
          className="frame1image30"
        />
        <span className="frame1-text200">Florero Elegante</span>
        <img
          alt="Rectangle6137"
          src="/rectangle6137-qw8g-200h.png"
          className="frame1-rectangle60"
        />
        <span className="frame1-text201">Agregar al Carrito</span>
        <img
          alt="Rectangle6137"
          src="/rectangle6137-vn6a-400h.png"
          className="frame1-rectangle61"
        />
        <img
          alt="IMAGE6137"
          src="/image6137-pun-300w.png"
          className="frame1image31"
        />
        <span className="frame1-text202">Florero Pequeño</span>
        <img
          alt="Rectangle6138"
          src="/rectangle6138-drhu-200h.png"
          className="frame1-rectangle62"
        />
        <span className="frame1-text203">Agregar al Carrito</span>
        <img
          alt="Rectangle6138"
          src="/rectangle6138-jkpj-400h.png"
          className="frame1-rectangle63"
        />
        <img
          alt="IMAGE6138"
          src="/image6138-l4m9-300w.png"
          className="frame1image32"
        />
        <span className="frame1-text204">Florero Alto Moderno</span>
        <img
          alt="Rectangle6138"
          src="/rectangle6138-gc1l-200h.png"
          className="frame1-rectangle64"
        />
        <span className="frame1-text205">Agregar al Carrito</span>
        <span className="frame1-text206">🏺</span>
        <span className="frame1-text207">Vasijas</span>
        <span className="frame1-text208">
          Vasijas tradicionales artesanales con historia y tradición
        </span>
        <img
          alt="Rectangle6139"
          src="/rectangle6139-jxfl-400h.png"
          className="frame1-rectangle65"
        />
        <img
          alt="IMAGE6139"
          src="/image6139-59b9-200h.png"
          className="frame1image33"
        />
        <span className="frame1-text209">Vasija Decorativa Grande</span>
        <img
          alt="Rectangle6139"
          src="/rectangle6139-0wly-200h.png"
          className="frame1-rectangle66"
        />
        <span className="frame1-text210">Agregar al Carrito</span>
        <img
          alt="Rectangle6139"
          src="/rectangle6139-xuxr-400h.png"
          className="frame1-rectangle67"
        />
        <img
          alt="IMAGE6139"
          src="/image6139-568-300w.png"
          className="frame1image34"
        />
        <span className="frame1-text211">Vasija Tradicional</span>
        <span className="frame1-text212">$55.000</span>
        <img
          alt="Rectangle6140"
          src="/rectangle6140-u1js-200h.png"
          className="frame1-rectangle68"
        />
        <span className="frame1-text213">Agregar al Carrito</span>
        <img
          alt="Rectangle6140"
          src="/rectangle6140-b6eu-400h.png"
          className="frame1-rectangle69"
        />
        <img
          alt="IMAGE6140"
          src="/image6140-l9o-300w.png"
          className="frame1image35"
        />
        <span className="frame1-text214">Vasija Pequeña</span>
        <img
          alt="Rectangle6140"
          src="/rectangle6140-eboi-200h.png"
          className="frame1-rectangle70"
        />
        <span className="frame1-text215">Agregar al Carrito</span>
        <img
          alt="Rectangle6140"
          src="/rectangle6140-4xk-200h.png"
          className="frame1-rectangle71"
        />
        <span className="frame1-text216">Ver Catálogo Completo</span>
        <img
          alt="Rectangle6141"
          src="/rectangle6141-6ktp-400h.png"
          className="frame1-rectangle72"
        />
        <span className="frame1-text217">Sobre Nosotros</span>
        <span className="frame1-text218">
          Artesanos dedicados a crear piezas únicas de cerámica con tradición y
          calidad.
        </span>
        <span className="frame1-text219">Categorías</span>
        <span className="frame1-text220">Alcancías</span>
        <span className="frame1-text221">Pocillos</span>
        <span className="frame1-text222">Platos</span>
        <span className="frame1-text223">Floreros</span>
        <span className="frame1-text224">Vasijas</span>
        <span className="frame1-text225">Atención al Cliente</span>
        <img
          alt="Rectangle6142"
          src="/rectangle6142-mczc-200h.png"
          className="frame1-rectangle73"
        />
        <span className="frame1-text226">YESA</span>
        <img
          alt="Rectangle6142"
          src="/rectangle6142-vhh-200h.png"
          className="frame1-rectangle74"
        />
        <span className="frame1-text227">🔍</span>
        <img
          alt="Rectangle6142"
          src="/rectangle6142-hs6bm-200h.png"
          className="frame1-rectangle75"
        />
        <span className="frame1-text228">Filtros</span>
        <img
          alt="Rectangle6142"
          src="/rectangle6142-b5vi-200h.png"
          className="frame1-rectangle76"
        />
        <span className="frame1-text229">🛒</span>
        <img
          alt="Rectangle6143"
          src="/rectangle6143-2m3m-200h.png"
          className="frame1-rectangle77"
        />
        <img
          alt="Rectangle6143"
          src="/rectangle6143-4xr-200h.png"
          className="frame1-rectangle78"
        />
        <span className="frame1-text230">Iniciar Sesión</span>
        <img
          alt="Rectangle6143"
          src="/rectangle6143-tj48-200h.png"
          className="frame1-rectangle79"
        />
        <span className="frame1-text231">-30%</span>
        <img
          alt="Rectangle6143"
          src="/rectangle6143-dvod-200h.png"
          className="frame1-rectangle80"
        />
        <span className="frame1-text232">-30%</span>
        <img
          alt="Rectangle6143"
          src="/rectangle6143-ju6g-200h.png"
          className="frame1-rectangle81"
        />
        <span className="frame1-text233">-30%</span>
        <img
          alt="Rectangle6144"
          src="/rectangle6144-8ok8-200h.png"
          className="frame1-rectangle82"
        />
        <span className="frame1-text234">-30%</span>
        <img
          alt="Rectangle6144"
          src="/rectangle6144-n2k2-200h.png"
          className="frame1-rectangle83"
        />
        <span className="frame1-text235">-30%</span>
        <img
          alt="Rectangle6144"
          src="/rectangle6144-no99-200h.png"
          className="frame1-rectangle84"
        />
        <span className="frame1-text236">-30%</span>
        <span className="frame1-text237">Buscar productos...</span>
        <span className="frame1-text238">Inicio</span>
        <span className="frame1-text239">Productos</span>
        <span className="frame1-text240">Contacto</span>
        <div className="frame1-fabmenu">
          <div className="frame1-menu">
            <div className="frame1-segment1"></div>
            <div className="frame1-segment2">
              <div className="frame1-statelayer1">
                <img
                  alt="IconI866"
                  src="/iconi866-juu.svg"
                  className="frame1-icon1"
                />
                <span className="frame1-text241 M3titlemedium">Chat</span>
              </div>
            </div>
          </div>
          <div className="frame1fab">
            <div className="frame1-statelayer2">
              <img
                alt="IconI866"
                src="/iconi866-18uj.svg"
                className="frame1-icon2"
              />
            </div>
          </div>
        </div>
      </div>
      <a href="https://play.teleporthq.io/signup" className="frame1-link">
        <div aria-label="Sign up to TeleportHQ" className="frame1-container2">
          <svg
            width="24"
            height="24"
            viewBox="0 0 19 21"
            fill="none"
            xmlns="http://www.w3.org/2000/svg"
            className="frame1-icon3"
          >
            <path
              d="M9.1017 4.64355H2.17867C0.711684 4.64355 -0.477539 5.79975 -0.477539 7.22599V13.9567C-0.477539 15.3829 0.711684 16.5391 2.17867 16.5391H9.1017C10.5687 16.5391 11.7579 15.3829 11.7579 13.9567V7.22599C11.7579 5.79975 10.5687 4.64355 9.1017 4.64355Z"
              fill="#B23ADE"
            ></path>
            <path
              d="M10.9733 12.7878C14.4208 12.7878 17.2156 10.0706 17.2156 6.71886C17.2156 3.3671 14.4208 0.649963 10.9733 0.649963C7.52573 0.649963 4.73096 3.3671 4.73096 6.71886C4.73096 10.0706 7.52573 12.7878 10.9733 12.7878Z"
              fill="#FF5C5C"
            ></path>
            <path
              d="M17.7373 13.3654C19.1497 14.1588 19.1497 15.4634 17.7373 16.2493L10.0865 20.5387C8.67402 21.332 7.51855 20.6836 7.51855 19.0968V10.5141C7.51855 8.92916 8.67402 8.2807 10.0865 9.07221L17.7373 13.3654Z"
              fill="#2874DE"
            ></path>
          </svg>
          <span className="frame1-text242">Built in TeleportHQ</span>
        </div>
      </a>
    </div>
  )
}

export default Frame1
