import React from 'react'

import { Helmet } from 'react-helmet'

import './frame2.css'

const Frame2 = (props) => {
  return (
    <div className="frame2-container1">
      <Helmet>
        <title>exported project</title>
        <meta property="og:title" content="exported project" />
        <link rel="canonical" href="https://yesa-okpqiu.teleporthq.app/" />
      </Helmet>
      <div className="frame2-frame2">
        <img
          alt="Rectangle5211"
          src="/rectangle5211-atvf-900h.png"
          className="frame2-rectangle10"
        />
        <img
          alt="Rectangle5211"
          src="/rectangle5211-vjvx-500w.png"
          className="frame2-rectangle11"
        />
        <span className="frame2-text10">CERÁMICA ARTESANAL</span>
        <span className="frame2-text11">Iniciar Sesión</span>
        <span className="frame2-text12">Accede a tu cuenta para continuar</span>
        <span className="frame2-text13">Correo Electrónico</span>
        <img
          alt="Rectangle5211"
          src="/rectangle5211-goqw-200h.png"
          className="frame2-rectangle12"
        />
        <span className="frame2-text14">📧</span>
        <span className="frame2-text15">Contraseña</span>
        <img
          alt="Rectangle5212"
          src="/rectangle5212-bg3a-200h.png"
          className="frame2-rectangle13"
        />
        <span className="frame2-text16">👁️</span>
        <img
          alt="Rectangle5212"
          src="/rectangle5212-o33k-200h.png"
          className="frame2-rectangle14"
        />
        <span className="frame2-text17">Recordarme</span>
        <span className="frame2-text18">¿Olvidaste tu contraseña?</span>
        <img
          alt="Rectangle5212"
          src="/rectangle5212-jzlt-200h.png"
          className="frame2-rectangle15"
        />
        <span className="frame2-text19">Iniciar Sesión</span>
        <img
          alt="Rectangle5212"
          src="/rectangle5212-q4vj-200h.png"
          className="frame2-rectangle16"
        />
        <span className="frame2-text20">o continúa con</span>
        <img
          alt="Rectangle5212"
          src="/rectangle5212-g1ri-200h.png"
          className="frame2-rectangle17"
        />
        <img
          alt="Rectangle5213"
          src="/rectangle5213-0zm-200h.png"
          className="frame2-rectangle18"
        />
        <span className="frame2-text21">🔍</span>
        <span className="frame2-text22">
          Google
          <span
            dangerouslySetInnerHTML={{
              __html: ' ',
            }}
          />
        </span>
        <span className="frame2-text23">¿No tienes una cuenta?</span>
        <span className="frame2-text24">Regístrate aquí</span>
        <img
          alt="Rectangle5213"
          src="/rectangle5213-zlu7-400w.png"
          className="frame2-rectangle19"
        />
        <span className="frame2-text25">
          Al iniciar sesión, aceptas nuestros
        </span>
        <span className="frame2-text26">Términos de Servicio</span>
        <span className="frame2-text27">Política de Privacidad</span>
        <span className="frame2-text28">Volver al inicio</span>
        <span className="frame2-text29">tu@email.com</span>
        <span className="frame2-text30">••••••••</span>
      </div>
      <a href="https://play.teleporthq.io/signup" className="frame2-link">
        <div aria-label="Sign up to TeleportHQ" className="frame2-container2">
          <svg
            width="24"
            height="24"
            viewBox="0 0 19 21"
            fill="none"
            xmlns="http://www.w3.org/2000/svg"
            className="frame2-icon1"
          >
            <path
              d="M9.1017 4.64355H2.17867C0.711684 4.64355 -0.477539 5.79975 -0.477539 7.22599V13.9567C-0.477539 15.3829 0.711684 16.5391 2.17867 16.5391H9.1017C10.5687 16.5391 11.7579 15.3829 11.7579 13.9567V7.22599C11.7579 5.79975 10.5687 4.64355 9.1017 4.64355Z"
              fill="#B23ADE"
            ></path>
            <path
              d="M10.9733 12.7878C14.4208 12.7878 17.2156 10.0706 17.2156 6.71886C17.2156 3.3671 14.4208 0.649963 10.9733 0.649963C7.52573 0.649963 4.73096 3.3671 4.73096 6.71886C4.73096 10.0706 7.52573 12.7878 10.9733 12.7878Z"
              fill="#FF5C5C"
            ></path>
            <path
              d="M17.7373 13.3654C19.1497 14.1588 19.1497 15.4634 17.7373 16.2493L10.0865 20.5387C8.67402 21.332 7.51855 20.6836 7.51855 19.0968V10.5141C7.51855 8.92916 8.67402 8.2807 10.0865 9.07221L17.7373 13.3654Z"
              fill="#2874DE"
            ></path>
          </svg>
          <span className="frame2-text31">Built in TeleportHQ</span>
        </div>
      </a>
    </div>
  )
}

export default Frame2
