import React from 'react'

import { Helmet } from 'react-helmet'

import './frame8.css'

const Frame8 = (props) => {
  return (
    <div className="frame8-container1">
      <Helmet>
        <title>Frame8 - exported project</title>
        <meta property="og:title" content="Frame8 - exported project" />
        <link
          rel="canonical"
          href="https://yesa-okpqiu.teleporthq.app/frame8"
        />
      </Helmet>
      <div className="frame8-frame8">
        <img
          alt="Rectangle7314"
          src="/rectangle7314-pc5s-1200h.png"
          className="frame8-rectangle10"
        />
        <img
          alt="Rectangle7314"
          src="/rectangle7314-q3yp-200h.png"
          className="frame8-rectangle11"
        />
        <span className="frame8-text10">YESA Admin</span>
        <img
          alt="Rectangle7314"
          src="/rectangle7314-49b-200w.png"
          className="frame8-rectangle12"
        />
        <span className="frame8-text11">Panel de Administración</span>
        <img
          alt="Rectangle7314"
          src="/rectangle7314-4g3h-200h.png"
          className="frame8-rectangle13"
        />
        <span className="frame8-text12">Lista de Productos</span>
        <img
          alt="Rectangle7315"
          src="/rectangle7315-6oa-200h.png"
          className="frame8-rectangle14"
        />
        <span className="frame8-text13">Agregar Producto</span>
        <span className="frame8-text14">Gestión de Productos</span>
        <span className="frame8-text15">
          Administra tu catálogo de productos de cerámica artesanal
        </span>
        <img
          alt="Rectangle7315"
          src="/rectangle7315-9ku5-200h.png"
          className="frame8-rectangle15"
        />
        <img
          alt="Rectangle7315"
          src="/rectangle7315-526f-200h.png"
          className="frame8-rectangle16"
        />
        <span className="frame8-text16">🔍</span>
        <img
          alt="Rectangle7315"
          src="/rectangle7315-v4ift-200h.png"
          className="frame8-rectangle17"
        />
        <img
          alt="Rectangle7315"
          src="/rectangle7315-miln-200h.png"
          className="frame8-rectangle18"
        />
        <span className="frame8-text17">+ Nuevo Producto</span>
        <img
          alt="Rectangle7316"
          src="/rectangle7316-io2t-400h.png"
          className="frame8-rectangle19"
        />
        <img
          alt="Rectangle7316"
          src="/rectangle7316-b5fi-200h.png"
          className="frame8-rectangle20"
        />
        <img
          alt="IMAGE7316"
          src="/image7316-t1yo-200h.png"
          className="frame8image1"
        />
        <img
          alt="Rectangle7316"
          src="/rectangle7316-py8i-200h.png"
          className="frame8-rectangle21"
        />
        <span className="frame8-text18">Alcancías</span>
        <span className="frame8-text19">Alcancía Cerámica Rosa</span>
        <span className="frame8-text20">
          Hermosa alcancía artesanal para ahorrar con estilo
        </span>
        <span className="frame8-text21">$28.000</span>
        <span className="frame8-text22">$35.000</span>
        <img
          alt="Rectangle7317"
          src="/rectangle7317-iswq-200h.png"
          className="frame8-rectangle22"
        />
        <span className="frame8-text23">✏️ Editar</span>
        <img
          alt="Rectangle7317"
          src="/rectangle7317-8wx8-200h.png"
          className="frame8-rectangle23"
        />
        <span className="frame8-text24">🗑️</span>
        <img
          alt="Rectangle7317"
          src="/rectangle7317-sp8g-400h.png"
          className="frame8-rectangle24"
        />
        <img
          alt="Rectangle7317"
          src="/rectangle7317-oxmg-200h.png"
          className="frame8-rectangle25"
        />
        <img
          alt="IMAGE7317"
          src="/image7317-ghaj-200h.png"
          className="frame8image2"
        />
        <img
          alt="Rectangle7317"
          src="/rectangle7317-uqu-200h.png"
          className="frame8-rectangle26"
        />
        <span className="frame8-text25">Pocillos</span>
        <span className="frame8-text26">Pocillo Artesanal Violeta</span>
        <span className="frame8-text27">
          Pocillo único hecho a mano para disfrutar tu café
        </span>
        <span className="frame8-text28">$19.000</span>
        <span className="frame8-text29">$25.000</span>
        <img
          alt="Rectangle7318"
          src="/rectangle7318-ee8u-200h.png"
          className="frame8-rectangle27"
        />
        <span className="frame8-text30">✏️ Editar</span>
        <img
          alt="Rectangle7318"
          src="/rectangle7318-wmn8-200h.png"
          className="frame8-rectangle28"
        />
        <span className="frame8-text31">🗑️</span>
        <img
          alt="Rectangle7318"
          src="/rectangle7318-za5j-400h.png"
          className="frame8-rectangle29"
        />
        <img
          alt="Rectangle7318"
          src="/rectangle7318-ghjh-200h.png"
          className="frame8-rectangle30"
        />
        <img
          alt="IMAGE7318"
          src="/image7318-92ru-200h.png"
          className="frame8image3"
        />
        <img
          alt="Rectangle7319"
          src="/rectangle7319-5he4-200h.png"
          className="frame8-rectangle31"
        />
        <span className="frame8-text32">Floreros</span>
        <span className="frame8-text33">Florero Elegante</span>
        <span className="frame8-text34">
          Florero decorativo único para embellecer tu hogar
        </span>
        <span className="frame8-text35">$45.000</span>
        <span className="frame8-text36">$60.000</span>
        <img
          alt="Rectangle7319"
          src="/rectangle7319-ldie-200h.png"
          className="frame8-rectangle32"
        />
        <span className="frame8-text37">✏️ Editar</span>
        <img
          alt="Rectangle7319"
          src="/rectangle7319-k7kr-200h.png"
          className="frame8-rectangle33"
        />
        <span className="frame8-text38">🗑️</span>
        <span className="frame8-text39">Buscar productos...</span>
        <span className="frame8-text40">Todas las categorías</span>
        <img
          alt="Vector7320"
          src="/vector7320-bji.svg"
          className="frame8-vector"
        />
      </div>
      <a href="https://play.teleporthq.io/signup" className="frame8-link">
        <div aria-label="Sign up to TeleportHQ" className="frame8-container2">
          <svg
            width="24"
            height="24"
            viewBox="0 0 19 21"
            fill="none"
            xmlns="http://www.w3.org/2000/svg"
            className="frame8-icon1"
          >
            <path
              d="M9.1017 4.64355H2.17867C0.711684 4.64355 -0.477539 5.79975 -0.477539 7.22599V13.9567C-0.477539 15.3829 0.711684 16.5391 2.17867 16.5391H9.1017C10.5687 16.5391 11.7579 15.3829 11.7579 13.9567V7.22599C11.7579 5.79975 10.5687 4.64355 9.1017 4.64355Z"
              fill="#B23ADE"
            ></path>
            <path
              d="M10.9733 12.7878C14.4208 12.7878 17.2156 10.0706 17.2156 6.71886C17.2156 3.3671 14.4208 0.649963 10.9733 0.649963C7.52573 0.649963 4.73096 3.3671 4.73096 6.71886C4.73096 10.0706 7.52573 12.7878 10.9733 12.7878Z"
              fill="#FF5C5C"
            ></path>
            <path
              d="M17.7373 13.3654C19.1497 14.1588 19.1497 15.4634 17.7373 16.2493L10.0865 20.5387C8.67402 21.332 7.51855 20.6836 7.51855 19.0968V10.5141C7.51855 8.92916 8.67402 8.2807 10.0865 9.07221L17.7373 13.3654Z"
              fill="#2874DE"
            ></path>
          </svg>
          <span className="frame8-text41">Built in TeleportHQ</span>
        </div>
      </a>
    </div>
  )
}

export default Frame8
