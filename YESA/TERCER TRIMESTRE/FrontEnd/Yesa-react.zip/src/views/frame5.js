import React from 'react'

import { Helmet } from 'react-helmet'

import './frame5.css'

const Frame5 = (props) => {
  return (
    <div className="frame5-container1">
      <Helmet>
        <title>Frame5 - exported project</title>
        <meta property="og:title" content="Frame5 - exported project" />
        <link
          rel="canonical"
          href="https://yesa-okpqiu.teleporthq.app/frame5"
        />
      </Helmet>
      <div className="frame5-frame5">
        <div className="frame5-group16">
          <img
            alt="Rectangle5411"
            src="/rectangle5411-42g-200h.png"
            className="frame5-rectangle10"
          />
          <span className="frame5-text10">💳 Finalizar Compra</span>
          <span className="frame5-text11">Información de Contacto</span>
          <span className="frame5-text12">Email</span>
          <img
            alt="Rectangle5412"
            src="/rectangle5412-ne8p-600w.png"
            className="frame5-rectangle11"
          />
          <span className="frame5-text13">Teléfono</span>
          <img
            alt="Rectangle5412"
            src="/rectangle5412-pcjd-600w.png"
            className="frame5-rectangle12"
          />
          <span className="frame5-text14">Dirección de Envío</span>
          <span className="frame5-text15">Dirección</span>
          <img
            alt="Rectangle5412"
            src="/rectangle5412-pbtk-600w.png"
            className="frame5-rectangle13"
          />
          <span className="frame5-text16">Ciudad</span>
          <img
            alt="Rectangle5412"
            src="/rectangle5412-axjp-600w.png"
            className="frame5-rectangle14"
          />
          <span className="frame5-text17">Método de Pago</span>
          <img
            alt="Rectangle5413"
            src="/rectangle5413-hlxxb-200h.png"
            className="frame5-rectangle15"
          />
          <img
            alt="Rectangle5413"
            src="/rectangle5413-om6o-200h.png"
            className="frame5-rectangle16"
          />
          <span className="frame5-text18">Pago Contra entrega</span>
          <span className="frame5-text19">💰 Efectivo</span>
          <span className="frame5-text20">Paga al recibir tu pedido</span>
          <span className="frame5-text21">Subtotal:</span>
          <span className="frame5-text22">$120.000</span>
          <span className="frame5-text23">Envío:</span>
          <span className="frame5-text24">Gratis</span>
          <img
            alt="Rectangle5415"
            src="/rectangle5415-sb8o-600w.png"
            className="frame5-rectangle17"
          />
          <span className="frame5-text25">Total:</span>
          <span className="frame5-text26">$120.000</span>
          <img
            alt="Rectangle5415"
            src="/rectangle5415-fmie-200h.png"
            className="frame5-rectangle18"
          />
          <span className="frame5-text27">Confirmar Pedido</span>
          <img
            alt="Rectangle5415"
            src="/rectangle5415-ifza-200h.png"
            className="frame5-rectangle19"
          />
          <span className="frame5-text28">Cancelar</span>
          <span className="frame5-text29">tu@email.com</span>
          <span className="frame5-text30">+57 300 123 4567</span>
          <span className="frame5-text31">Calle 123 #45-67</span>
          <span className="frame5-text32">Bogotá</span>
        </div>
      </div>
      <a href="https://play.teleporthq.io/signup" className="frame5-link">
        <div aria-label="Sign up to TeleportHQ" className="frame5-container2">
          <svg
            width="24"
            height="24"
            viewBox="0 0 19 21"
            fill="none"
            xmlns="http://www.w3.org/2000/svg"
            className="frame5-icon1"
          >
            <path
              d="M9.1017 4.64355H2.17867C0.711684 4.64355 -0.477539 5.79975 -0.477539 7.22599V13.9567C-0.477539 15.3829 0.711684 16.5391 2.17867 16.5391H9.1017C10.5687 16.5391 11.7579 15.3829 11.7579 13.9567V7.22599C11.7579 5.79975 10.5687 4.64355 9.1017 4.64355Z"
              fill="#B23ADE"
            ></path>
            <path
              d="M10.9733 12.7878C14.4208 12.7878 17.2156 10.0706 17.2156 6.71886C17.2156 3.3671 14.4208 0.649963 10.9733 0.649963C7.52573 0.649963 4.73096 3.3671 4.73096 6.71886C4.73096 10.0706 7.52573 12.7878 10.9733 12.7878Z"
              fill="#FF5C5C"
            ></path>
            <path
              d="M17.7373 13.3654C19.1497 14.1588 19.1497 15.4634 17.7373 16.2493L10.0865 20.5387C8.67402 21.332 7.51855 20.6836 7.51855 19.0968V10.5141C7.51855 8.92916 8.67402 8.2807 10.0865 9.07221L17.7373 13.3654Z"
              fill="#2874DE"
            ></path>
          </svg>
          <span className="frame5-text33">Built in TeleportHQ</span>
        </div>
      </a>
    </div>
  )
}

export default Frame5
