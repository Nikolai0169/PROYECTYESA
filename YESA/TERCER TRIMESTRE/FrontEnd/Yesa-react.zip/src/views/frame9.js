import React from 'react'

import { Helmet } from 'react-helmet'

import './frame9.css'

const Frame9 = (props) => {
  return (
    <div className="frame9-container1">
      <Helmet>
        <title>Frame9 - exported project</title>
        <meta property="og:title" content="Frame9 - exported project" />
        <link
          rel="canonical"
          href="https://yesa-okpqiu.teleporthq.app/frame9"
        />
      </Helmet>
      <div className="frame9-frame9">
        <img
          alt="Rectangle7320"
          src="/rectangle7320-7sfk-1000h.png"
          className="frame9-rectangle10"
        />
        <img
          alt="Rectangle7320"
          src="/rectangle7320-7idt-200h.png"
          className="frame9-rectangle11"
        />
        <span className="frame9-text10">YESA Admin</span>
        <img
          alt="Rectangle7320"
          src="/rectangle7320-ezoj-200h.png"
          className="frame9-rectangle12"
        />
        <span className="frame9-text11">Gestión de Clientes</span>
        <span className="frame9-text12">clientes</span>
        <span className="frame9-text13">Base de Datos de Clientes</span>
        <span className="frame9-text14">
          Administra la información de tus clientes registrados
        </span>
        <img
          alt="Rectangle7321"
          src="/rectangle7321-lo7n-200h.png"
          className="frame9-rectangle13"
        />
        <img
          alt="Rectangle7321"
          src="/rectangle7321-km8k-200h.png"
          className="frame9-rectangle14"
        />
        <span className="frame9-text15">🔍</span>
        <img
          alt="Rectangle7321"
          src="/rectangle7321-6do-200h.png"
          className="frame9-rectangle15"
        />
        <img
          alt="Rectangle7321"
          src="/rectangle7321-clxp-200h.png"
          className="frame9-rectangle16"
        />
        <img
          alt="Rectangle7321"
          src="/rectangle7321-ydb-200h.png"
          className="frame9-rectangle17"
        />
        <span className="frame9-text16">↑ Ascendente</span>
        <img
          alt="Rectangle7322"
          src="/rectangle7322-lk3d-500h.png"
          className="frame9-rectangle18"
        />
        <img
          alt="Rectangle7322"
          src="/rectangle7322-ax-200h.png"
          className="frame9-rectangle19"
        />
        <span className="frame9-text17">Cliente</span>
        <span className="frame9-text18">Contacto</span>
        <span className="frame9-text19">Registro</span>
        <span className="frame9-text20">Pedidos</span>
        <span className="frame9-text21">Total Gastado</span>
        <span className="frame9-text22">Acciones</span>
        <img
          alt="Rectangle7322"
          src="/rectangle7322-ai7e-1300w.png"
          className="frame9-rectangle20"
        />
        <img
          alt="Rectangle7322"
          src="/rectangle7322-ymq-200h.png"
          className="frame9-rectangle21"
        />
        <span className="frame9-text23">Ana Martínez</span>
        <img
          alt="Rectangle7323"
          src="/rectangle7323-jpudr-200h.png"
          className="frame9-rectangle22"
        />
        <span className="frame9-text24">Activo</span>
        <span className="frame9-text25">ana.martinez@email.com</span>
        <span className="frame9-text26">+57 302 345 6789</span>
        <span className="frame9-text27">7 de enero de 2024</span>
        <span className="frame9-text28">Último:</span>
        <span className="frame9-text29">11 de marzo de 2024</span>
        <span className="frame9-text30">12</span>
        <span className="frame9-text31">pedidos</span>
        <span className="frame9-text32">$456.000</span>
        <span className="frame9-text33">total</span>
        <img
          alt="Rectangle7324"
          src="/rectangle7324-9q0p-200h.png"
          className="frame9-rectangle23"
        />
        <span className="frame9-text34">👁️ Ver</span>
        <img
          alt="Rectangle7324"
          src="/rectangle7324-s54h-200h.png"
          className="frame9-rectangle24"
        />
        <span className="frame9-text35">✏️ Editar</span>
        <img
          alt="Rectangle7324"
          src="/rectangle7324-9r5q-1300w.png"
          className="frame9-rectangle25"
        />
        <img
          alt="Rectangle7324"
          src="/rectangle7324-dm7-200h.png"
          className="frame9-rectangle26"
        />
        <span className="frame9-text36">Carlos Rodríguez</span>
        <img
          alt="Rectangle7325"
          src="/rectangle7325-cdk6-200h.png"
          className="frame9-rectangle27"
        />
        <span className="frame9-text37">Activo</span>
        <span className="frame9-text38">carlos.rodriguez@email.com</span>
        <span className="frame9-text39">+57 301 234 5678</span>
        <span className="frame9-text40">19 de febrero de 2024</span>
        <span className="frame9-text41">Último:</span>
        <span className="frame9-text42">7 de marzo de 2024</span>
        <span className="frame9-text43">pedidos</span>
        <span className="frame9-text44">$89.000</span>
        <span className="frame9-text45">total</span>
        <img
          alt="Rectangle7326"
          src="/rectangle7326-q69h-200h.png"
          className="frame9-rectangle28"
        />
        <span className="frame9-text46">👁️ Ver</span>
        <img
          alt="Rectangle7326"
          src="/rectangle7326-uktrub-200h.png"
          className="frame9-rectangle29"
        />
        <span className="frame9-text47">✏️ Editar</span>
        <img
          alt="Rectangle7326"
          src="/rectangle7326-y3sa-1300w.png"
          className="frame9-rectangle30"
        />
        <img
          alt="Rectangle7326"
          src="/rectangle7326-adx-200h.png"
          className="frame9-rectangle31"
        />
        <span className="frame9-text48">Luis Hernández</span>
        <img
          alt="Rectangle7327"
          src="/rectangle7327-p1d-200h.png"
          className="frame9-rectangle32"
        />
        <span className="frame9-text49">Inactivo</span>
        <span className="frame9-text50">luis.hernandez@email.com</span>
        <span className="frame9-text51">+57 303 456 7890</span>
        <span className="frame9-text52">21 de noviembre de 2023</span>
        <span className="frame9-text53">Último:</span>
        <span className="frame9-text54">4 de diciembre de 2023</span>
        <span className="frame9-text55">pedidos</span>
        <span className="frame9-text56">$28.000</span>
        <span className="frame9-text57">total</span>
        <img
          alt="Rectangle7328"
          src="/rectangle7328-95v-200h.png"
          className="frame9-rectangle33"
        />
        <span className="frame9-text58">👁️ Ver</span>
        <img
          alt="Rectangle7328"
          src="/rectangle7328-dxtc-200h.png"
          className="frame9-rectangle34"
        />
        <span className="frame9-text59">✏️ Editar</span>
        <img
          alt="Rectangle7328"
          src="/rectangle7328-0ey-1300w.png"
          className="frame9-rectangle35"
        />
        <img
          alt="Rectangle7328"
          src="/rectangle7328-4y3yf-200h.png"
          className="frame9-rectangle36"
        />
        <span className="frame9-text60">María González</span>
        <img
          alt="Rectangle7328"
          src="/rectangle7328-tknk-200h.png"
          className="frame9-rectangle37"
        />
        <span className="frame9-text61">Activo</span>
        <span className="frame9-text62">maria.gonzalez@email.com</span>
        <span className="frame9-text63">+57 300 123 4567</span>
        <span className="frame9-text64">14 de enero de 2024</span>
        <span className="frame9-text65">Último:</span>
        <span className="frame9-text66">9 de marzo de 2024</span>
        <span className="frame9-text67">pedidos</span>
        <span className="frame9-text68">$245.000</span>
        <span className="frame9-text69">total</span>
        <img
          alt="Rectangle7330"
          src="/rectangle7330-vmtk-200h.png"
          className="frame9-rectangle38"
        />
        <span className="frame9-text70">👁️ Ver</span>
        <img
          alt="Rectangle7330"
          src="/rectangle7330-o4g2b-200h.png"
          className="frame9-rectangle39"
        />
        <span className="frame9-text71">✏️ Editar</span>
        <img
          alt="Rectangle7330"
          src="/rectangle7330-rbwt-200h.png"
          className="frame9-rectangle40"
        />
        <span className="frame9-text72">Patricia Silva</span>
        <img
          alt="Rectangle7330"
          src="/rectangle7330-jq44-200h.png"
          className="frame9-rectangle41"
        />
        <span className="frame9-text73">Activo</span>
        <span className="frame9-text74">patricia.silva@email.com</span>
        <span className="frame9-text75">+57 304 567 8901</span>
        <span className="frame9-text76">13 de febrero de 2024</span>
        <span className="frame9-text77">Último:</span>
        <span className="frame9-text78">10 de marzo de 2024</span>
        <span className="frame9-text79">pedidos</span>
        <span className="frame9-text80">$178.000</span>
        <span className="frame9-text81">total</span>
        <img
          alt="Rectangle7331"
          src="/rectangle7331-vu0h-200h.png"
          className="frame9-rectangle42"
        />
        <span className="frame9-text82">👁️ Ver</span>
        <img
          alt="Rectangle7332"
          src="/rectangle7332-luo-200h.png"
          className="frame9-rectangle43"
        />
        <span className="frame9-text83">✏️ Editar</span>
        <img
          alt="Rectangle7332"
          src="/rectangle7332-smwp-200h.png"
          className="frame9-rectangle44"
        />
        <span className="frame9-text84">Total Clientes</span>
        <img
          alt="Rectangle7332"
          src="/rectangle7332-b3w-200h.png"
          className="frame9-rectangle45"
        />
        <span className="frame9-text85">👥</span>
        <img
          alt="Rectangle7332"
          src="/rectangle7332-75r-200h.png"
          className="frame9-rectangle46"
        />
        <span className="frame9-text86">Clientes Activos</span>
        <img
          alt="Rectangle7333"
          src="/rectangle7333-c7y-200h.png"
          className="frame9-rectangle47"
        />
        <img
          alt="Rectangle7333"
          src="/rectangle7333-sls-200h.png"
          className="frame9-rectangle48"
        />
        <span className="frame9-text87">Ventas Totales</span>
        <span className="frame9-text88">$996.000</span>
        <img
          alt="Rectangle7333"
          src="/rectangle7333-lzdd-200h.png"
          className="frame9-rectangle49"
        />
        <span className="frame9-text89">💰</span>
        <span className="frame9-text90">Buscar por nombre o email...</span>
        <span className="frame9-text91">Todos los estados</span>
        <span className="frame9-text92">Ordenar por nombre</span>
        <img
          alt="Vector7334"
          src="/vector7334-nymg.svg"
          className="frame9-vector1"
        />
        <img
          alt="Vector7334"
          src="/vector7334-1pob.svg"
          className="frame9-vector2"
        />
      </div>
      <a href="https://play.teleporthq.io/signup" className="frame9-link">
        <div aria-label="Sign up to TeleportHQ" className="frame9-container2">
          <svg
            width="24"
            height="24"
            viewBox="0 0 19 21"
            fill="none"
            xmlns="http://www.w3.org/2000/svg"
            className="frame9-icon1"
          >
            <path
              d="M9.1017 4.64355H2.17867C0.711684 4.64355 -0.477539 5.79975 -0.477539 7.22599V13.9567C-0.477539 15.3829 0.711684 16.5391 2.17867 16.5391H9.1017C10.5687 16.5391 11.7579 15.3829 11.7579 13.9567V7.22599C11.7579 5.79975 10.5687 4.64355 9.1017 4.64355Z"
              fill="#B23ADE"
            ></path>
            <path
              d="M10.9733 12.7878C14.4208 12.7878 17.2156 10.0706 17.2156 6.71886C17.2156 3.3671 14.4208 0.649963 10.9733 0.649963C7.52573 0.649963 4.73096 3.3671 4.73096 6.71886C4.73096 10.0706 7.52573 12.7878 10.9733 12.7878Z"
              fill="#FF5C5C"
            ></path>
            <path
              d="M17.7373 13.3654C19.1497 14.1588 19.1497 15.4634 17.7373 16.2493L10.0865 20.5387C8.67402 21.332 7.51855 20.6836 7.51855 19.0968V10.5141C7.51855 8.92916 8.67402 8.2807 10.0865 9.07221L17.7373 13.3654Z"
              fill="#2874DE"
            ></path>
          </svg>
          <span className="frame9-text93">Built in TeleportHQ</span>
        </div>
      </a>
    </div>
  )
}

export default Frame9
