import React from 'react'

import { Helmet } from 'react-helmet'

import './frame3.css'

const Frame3 = (props) => {
  return (
    <div className="frame3-container1">
      <Helmet>
        <title>Frame3 - exported project</title>
        <meta property="og:title" content="Frame3 - exported project" />
        <link
          rel="canonical"
          href="https://yesa-okpqiu.teleporthq.app/frame3"
        />
      </Helmet>
      <div className="frame3-frame3">
        <img
          alt="Rectangle5315"
          src="/rectangle5315-fzk-1100h.png"
          className="frame3-rectangle10"
        />
        <span className="frame3-text10">CERÁMICA ARTESANAL</span>
        <span className="frame3-text11">Crear Cuenta</span>
        <span className="frame3-text12">
          Únete a nuestra comunidad artesanal
        </span>
        <span className="frame3-text13">Nombre</span>
        <img
          alt="Rectangle5315"
          src="/rectangle5315-xuni-200h.png"
          className="frame3-rectangle11"
        />
        <span className="frame3-text14">👤</span>
        <span className="frame3-text15">Apellido</span>
        <img
          alt="Rectangle5315"
          src="/rectangle5315-bn1s-200h.png"
          className="frame3-rectangle12"
        />
        <span className="frame3-text16">👤</span>
        <span className="frame3-text17">Correo Electrónico</span>
        <img
          alt="Rectangle5316"
          src="/rectangle5316-d4ub-200h.png"
          className="frame3-rectangle13"
        />
        <span className="frame3-text18">📧</span>
        <span className="frame3-text19">Contraseña</span>
        <img
          alt="Rectangle5316"
          src="/rectangle5316-i1w-200h.png"
          className="frame3-rectangle14"
        />
        <span className="frame3-text20">🙈</span>
        <span className="frame3-text21">Confirmar Contraseña</span>
        <img
          alt="Rectangle5316"
          src="/rectangle5316-h7d-200h.png"
          className="frame3-rectangle15"
        />
        <span className="frame3-text22">🙈</span>
        <img
          alt="Rectangle5316"
          src="/rectangle5316-7znr-200h.png"
          className="frame3-rectangle16"
        />
        <span className="frame3-text23">Acepto los</span>
        <span className="frame3-text24">Términos de Servicio</span>
        <span className="frame3-text25">Política de Privacidad</span>
        <img
          alt="Rectangle5317"
          src="/rectangle5317-45s-200h.png"
          className="frame3-rectangle17"
        />
        <span className="frame3-text26">Crear Cuenta</span>
        <img
          alt="Rectangle5317"
          src="/rectangle5317-22tb-200h.png"
          className="frame3-rectangle18"
        />
        <span className="frame3-text27">o regístrate con</span>
        <img
          alt="Rectangle5317"
          src="/rectangle5317-1mlu-200h.png"
          className="frame3-rectangle19"
        />
        <img
          alt="Rectangle5317"
          src="/rectangle5317-0g2i-200h.png"
          className="frame3-rectangle20"
        />
        <span className="frame3-text28">🔍</span>
        <span className="frame3-text29">Google</span>
        <span className="frame3-text30">¿Ya tienes una cuenta?</span>
        <span className="frame3-text31">Inicia sesión aquí</span>
        <img
          alt="Rectangle5318"
          src="/rectangle5318-dnpl-400w.png"
          className="frame3-rectangle21"
        />
        <span className="frame3-text32">
          Al crear una cuenta, aceptas nuestros
        </span>
        <span className="frame3-text33">Términos de Servicio</span>
        <span className="frame3-text34">Política de Privacidad</span>
        <span className="frame3-text35">Volver al inicio</span>
        <span className="frame3-text36">Tu nombre</span>
        <span className="frame3-text37">Tu apellido</span>
        <span className="frame3-text38">tu@email.com</span>
        <span className="frame3-text39">••••••••</span>
        <span className="frame3-text40">••••••••</span>
      </div>
      <a href="https://play.teleporthq.io/signup" className="frame3-link">
        <div aria-label="Sign up to TeleportHQ" className="frame3-container2">
          <svg
            width="24"
            height="24"
            viewBox="0 0 19 21"
            fill="none"
            xmlns="http://www.w3.org/2000/svg"
            className="frame3-icon1"
          >
            <path
              d="M9.1017 4.64355H2.17867C0.711684 4.64355 -0.477539 5.79975 -0.477539 7.22599V13.9567C-0.477539 15.3829 0.711684 16.5391 2.17867 16.5391H9.1017C10.5687 16.5391 11.7579 15.3829 11.7579 13.9567V7.22599C11.7579 5.79975 10.5687 4.64355 9.1017 4.64355Z"
              fill="#B23ADE"
            ></path>
            <path
              d="M10.9733 12.7878C14.4208 12.7878 17.2156 10.0706 17.2156 6.71886C17.2156 3.3671 14.4208 0.649963 10.9733 0.649963C7.52573 0.649963 4.73096 3.3671 4.73096 6.71886C4.73096 10.0706 7.52573 12.7878 10.9733 12.7878Z"
              fill="#FF5C5C"
            ></path>
            <path
              d="M17.7373 13.3654C19.1497 14.1588 19.1497 15.4634 17.7373 16.2493L10.0865 20.5387C8.67402 21.332 7.51855 20.6836 7.51855 19.0968V10.5141C7.51855 8.92916 8.67402 8.2807 10.0865 9.07221L17.7373 13.3654Z"
              fill="#2874DE"
            ></path>
          </svg>
          <span className="frame3-text41">Built in TeleportHQ</span>
        </div>
      </a>
    </div>
  )
}

export default Frame3
