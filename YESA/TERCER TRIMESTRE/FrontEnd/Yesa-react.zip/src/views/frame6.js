import React from 'react'

import { Helmet } from 'react-helmet'

import './frame6.css'

const Frame6 = (props) => {
  return (
    <div className="frame6-container1">
      <Helmet>
        <title>Frame6 - exported project</title>
        <meta property="og:title" content="Frame6 - exported project" />
        <link
          rel="canonical"
          href="https://yesa-okpqiu.teleporthq.app/frame6"
        />
      </Helmet>
      <div className="frame6-frame6">
        <div className="frame6-frame4">
          <img
            alt="Rectangle7115"
            src="/rectangle7115-udp7t-1300w.png"
            className="frame6-rectangle10"
          />
          <img
            alt="Rectangle7116"
            src="/rectangle7116-3nn9-1400h.png"
            className="frame6-rectangle11"
          />
          <img
            alt="Rectangle7117"
            src="/rectangle7117-mlio-600h.png"
            className="frame6-rectangle12"
          />
          <img
            alt="IMAGE7118"
            src="/image7118-kxbt-600h.png"
            className="frame6image1"
          />
          <img
            alt="Rectangle7119"
            src="/rectangle7119-nln2-200h.png"
            className="frame6-rectangle13"
          />
          <img
            alt="IMAGE7120"
            src="/image7120-zai6-200h.png"
            className="frame6image2"
          />
          <img
            alt="Rectangle7121"
            src="/rectangle7121-o2n-200h.png"
            className="frame6-rectangle14"
          />
          <img
            alt="IMAGE7122"
            src="/image7122-bxtv-200h.png"
            className="frame6image3"
          />
          <img
            alt="Rectangle7123"
            src="/rectangle7123-56fa-200h.png"
            className="frame6-rectangle15"
          />
          <img
            alt="IMAGE7124"
            src="/image7124-vynf-200h.png"
            className="frame6image4"
          />
          <span className="frame6-text10">Alcancía Cerámica Rosa</span>
          <span className="frame6-text11">$19.600</span>
          <span className="frame6-text12">$28.000</span>
          <img
            alt="Rectangle7128"
            src="/rectangle7128-ment-200h.png"
            className="frame6-rectangle16"
          />
          <span className="frame6-text13">30% OFF</span>
          <span className="frame6-text14">Ahorras:</span>
          <span className="frame6-text15">$8.400</span>
          <span className="frame6-text16">Descripción</span>
          <span className="frame6-text17">
            Hermosa alcancía artesanal elaborada en cerámica de alta calidad con
            un elegante acabado en rosa. Perfecta para enseñar a los niños el
            valor del ahorro o como elemento decorativo en cualquier espacio.
            Cada pieza es única, hecha a mano por artesanos expertos que
            mantienen viva la tradición cerámica.
          </span>
          <span className="frame6-text18">
            • Material: Cerámica de alta calidad
          </span>
          <span className="frame6-text19">
            • Dimensiones: 15cm x 12cm x 10cm
          </span>
          <span className="frame6-text20">• Peso: 450 gramos</span>
          <span className="frame6-text21">• Acabado: Esmaltado brillante</span>
          <span className="frame6-text22">
            • Ranura para monedas en la parte superior
          </span>
          <span className="frame6-text23">• Tapón removible en la base</span>
          <img
            alt="Rectangle7140"
            src="/rectangle7140-2evt-200h.png"
            className="frame6-rectangle17"
          />
          <span className="frame6-text24">🛒 Agregar al Carrito</span>
          <img
            alt="Rectangle7142"
            src="/rectangle7142-2eko-600w.png"
            className="frame6-rectangle18"
          />
          <span className="frame6-text25">♡ Agregar a Favoritos</span>
          <img
            alt="Rectangle7144"
            src="/rectangle7144-xltr-1200w.png"
            className="frame6-rectangle19"
          />
          <span className="frame6-text26">Opiniones de Clientes</span>
          <img
            alt="Rectangle7146"
            src="/rectangle7146-vrgk-200h.png"
            className="frame6-rectangle20"
          />
          <span className="frame6-text27">Escribir Reseña</span>
          <img
            alt="Rectangle7148"
            src="/rectangle7148-kmtq-200h.png"
            className="frame6-rectangle21"
          />
          <span className="frame6-text28">María González</span>
          <span className="frame6-text29">15 de marzo, 2024</span>
          <span className="frame6-text30">
            Hermosa alcancía, la calidad es excelente y llegó muy bien empacada.
            Perfecta para mi hija.
          </span>
          <img
            alt="Rectangle7157"
            src="/rectangle7157-yue7-200h.png"
            className="frame6-rectangle22"
          />
          <span className="frame6-text31">Carlos Rodríguez</span>
          <span className="frame6-text32">8 de marzo, 2024</span>
          <span className="frame6-text33">
            Muy bonita y bien hecha. El color es exactamente como en las fotos.
            Recomendada.
          </span>
          <img
            alt="Rectangle7166"
            src="/rectangle7166-vm9-200h.png"
            className="frame6-rectangle23"
          />
          <span className="frame6-text34">Ana Martínez</span>
          <span className="frame6-text35">2 de marzo, 2024</span>
          <span className="frame6-text36">
            Artesanía de primera calidad. Se nota el trabajo manual y el cuidado
            en los detalles.
          </span>
          <img
            alt="Rectangle7175"
            src="/rectangle7175-e27s-300w.png"
            className="frame6-rectangle24"
          />
          <span className="frame6-text37">Ver Todas las Reseñas</span>
        </div>
      </div>
      <a href="https://play.teleporthq.io/signup" className="frame6-link">
        <div aria-label="Sign up to TeleportHQ" className="frame6-container2">
          <svg
            width="24"
            height="24"
            viewBox="0 0 19 21"
            fill="none"
            xmlns="http://www.w3.org/2000/svg"
            className="frame6-icon1"
          >
            <path
              d="M9.1017 4.64355H2.17867C0.711684 4.64355 -0.477539 5.79975 -0.477539 7.22599V13.9567C-0.477539 15.3829 0.711684 16.5391 2.17867 16.5391H9.1017C10.5687 16.5391 11.7579 15.3829 11.7579 13.9567V7.22599C11.7579 5.79975 10.5687 4.64355 9.1017 4.64355Z"
              fill="#B23ADE"
            ></path>
            <path
              d="M10.9733 12.7878C14.4208 12.7878 17.2156 10.0706 17.2156 6.71886C17.2156 3.3671 14.4208 0.649963 10.9733 0.649963C7.52573 0.649963 4.73096 3.3671 4.73096 6.71886C4.73096 10.0706 7.52573 12.7878 10.9733 12.7878Z"
              fill="#FF5C5C"
            ></path>
            <path
              d="M17.7373 13.3654C19.1497 14.1588 19.1497 15.4634 17.7373 16.2493L10.0865 20.5387C8.67402 21.332 7.51855 20.6836 7.51855 19.0968V10.5141C7.51855 8.92916 8.67402 8.2807 10.0865 9.07221L17.7373 13.3654Z"
              fill="#2874DE"
            ></path>
          </svg>
          <span className="frame6-text38">Built in TeleportHQ</span>
        </div>
      </a>
    </div>
  )
}

export default Frame6
